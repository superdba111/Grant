import json

def handler(event, context):
    http_method = event['requestContext']['http']['method']
    if http_method == 'GET':
        return {
            'statusCode': 200,
            'body': 'Getting...'
        }
    elif http_method == 'POST':
        # unitprice = event['body-json']['unitprice']
        # weight = event['body-json']['weight']
        # unitprice = event['body']['unitprice']
        unitprice = json.loads(event['body'])['unitprice']
        # weight = event['body']['weight'])
        weight = json.loads(event['body'])['weight']
        total = unitprice * weight
        return {
            'statusCode': 200,
            'body': f'Posting... total: {total}'
        }
    else:
        return {
            'statusCode': 400,
            'body': 'Invalid request method'
        }


