from aws_cdk import (
    aws_lambda,
    aws_apigatewayv2 as apigw,
    aws_apigatewayv2_integrations as apigw_integrations,
    core,
)

# from lambda_function import handler


class LambdaRestApiStack(core.Stack):

    def __init__(self, scope: core.Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # Define the Lambda function
        lambda_func = aws_lambda.Function(
            self,
            "LambdaFunction",
            runtime=aws_lambda.Runtime.PYTHON_3_8,
            handler="handler.handler",
            code=aws_lambda.Code.from_asset("lambda"),
        )
        barometer_integration = apigw_integrations.HttpLambdaIntegration(id='LambdaLogicalID', handler=lambda_func)

        # Define the REST API
        rest_api = apigw.HttpApi(
            self,
            "RestApi",
            # default_integration=apigw_integrations.LambdaProxyIntegration(
            #     handler=lambda_func
            # ),
            default_integration = barometer_integration,
            api_name="BarometerAPI",
        )

        # Add /barometer endpoint
        rest_api.add_routes(
            path="/barometer",
            methods=[apigw.HttpMethod.GET, apigw.HttpMethod.POST],
            integration=barometer_integration
        )
        # http_api.add_routes(
        #     path="/barometer",
        #     methods=[apigwv2.HttpMethod.GET],
        #     integration=books_integration
        # )

app = core.App()

LambdaRestApiStack(app, "lambda-rest-api")

app.synth()
